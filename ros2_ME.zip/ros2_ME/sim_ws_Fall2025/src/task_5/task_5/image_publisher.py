import os
import cv2
from ament_index_python.packages import get_package_share_directory

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')

        qos = QoSProfile(depth=10)
        qos.reliability = ReliabilityPolicy.BEST_EFFORT
        qos.durability = DurabilityPolicy.VOLATILE

        self.pub = self.create_publisher(Image, '/video_data', qos)
        self.bridge = CvBridge()

        
        pkg_share = get_package_share_directory('task_5')
        default_path = os.path.join(pkg_share, 'resource', 'lab3_video.avi')

        self.declare_parameter('video_path', default_path)
        p = self.get_parameter('video_path').get_parameter_value().string_value
        self.video_path = p if (p and p.strip()) else default_path

        if not os.path.exists(self.video_path):
            self.get_logger().error(f'Video not found: {self.video_path}')

      
        self.cap = cv2.VideoCapture(self.video_path)
        if not self.cap.isOpened():
         
            self.get_logger().warn('OpenCV could not open with default backend; retrying with CAP_FFMPEG...')
            self.cap = cv2.VideoCapture(self.video_path, cv2.CAP_FFMPEG)

       
        self.show_video = True

       
        self.timer = self.create_timer(1.0/30.0, self._tick)
        self.get_logger().info(f'Publishing video from: {self.video_path} at ~30Hz')

    def _tick(self):
        if not self.cap.isOpened():
            self.cap.open(self.video_path)
            if not self.cap.isOpened():
                self.get_logger().error('Cannot open video capture.')
                return

        success, frame = self.cap.read()  
        if not success or frame is None:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            return

        # convert cv2 image 
        ros_img = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        self.pub.publish(ros_img)

        # visualize 
        if self.show_video:
            cv2.imshow('Publisher Preview', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'): 
                self.show_video = False
                cv2.destroyAllWindows()

    def destroy_node(self):
        if hasattr(self, 'cap') and self.cap is not None:
            self.cap.release()  
        try:
            cv2.destroyAllWindows() 
        except Exception:
            pass
        super().destroy_node()


def main():
    rclpy.init()
    node = ImagePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
