import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

from sensor_msgs.msg import Image
from vision_msgs.msg import BoundingBox2D, Pose2D
from cv_bridge import CvBridge


class ObjectDetector(Node):
    def __init__(self):
        super().__init__('object_detector_red_triangle')

        qos = QoSProfile(depth=10)
        qos.reliability = ReliabilityPolicy.BEST_EFFORT
        qos.durability = DurabilityPolicy.VOLATILE

        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, '/video_data', self.image_cb, qos)
        self.pub_bbox = self.create_publisher(BoundingBox2D, '/bbox', 10)

        self.kernel_open = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        self.kernel_dil  = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

        self.declare_parameter('hsv_H_low1', 0)
        self.declare_parameter('hsv_H_high1', 10)
        self.declare_parameter('hsv_H_low2', 160)
        self.declare_parameter('hsv_H_high2', 179)
        self.declare_parameter('hsv_S_low', 100)
        self.declare_parameter('hsv_S_high', 255)
        self.declare_parameter('hsv_V_low', 80)
        self.declare_parameter('hsv_V_high', 255)

        self.declare_parameter('min_area', 800)
        self.declare_parameter('approx_eps_ratio', 0.04)
        self.declare_parameter('require_convex', True)
        self.declare_parameter('min_solidity', 0.85)

        self.show_video = True

        self.get_logger().info('Red-triangle ObjectDetector ready. Subscribing to /video_data')

    def _set_pose2d(self, pose: Pose2D, x: float, y: float) -> bool:
        if hasattr(pose, 'x') and hasattr(pose, 'y'):
            pose.x = float(x); pose.y = float(y)
        elif hasattr(pose, 'position') and hasattr(pose.position, 'x') and hasattr(pose.position, 'y'):
            pose.position.x = float(x); pose.position.y = float(y)
        else:
            return False
        if hasattr(pose, 'theta'):
            pose.theta = 0.0
        return True

    def image_cb(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        if frame is None:
            return
        blur = cv2.medianBlur(frame, 5)
        hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)

        h1_low  = int(self.get_parameter('hsv_H_low1').value)
        h1_high = int(self.get_parameter('hsv_H_high1').value)
        h2_low  = int(self.get_parameter('hsv_H_low2').value)
        h2_high = int(self.get_parameter('hsv_H_high2').value)
        s_low   = int(self.get_parameter('hsv_S_low').value)
        s_high  = int(self.get_parameter('hsv_S_high').value)
        v_low   = int(self.get_parameter('hsv_V_low').value)
        v_high  = int(self.get_parameter('hsv_V_high').value)

        min_area = int(self.get_parameter('min_area').value)
        approx_eps_ratio = float(self.get_parameter('approx_eps_ratio').value)
        require_convex = bool(self.get_parameter('require_convex').value)
        min_solidity = float(self.get_parameter('min_solidity').value)

        lower1 = np.array([h1_low, s_low, v_low], dtype=np.uint8)
        upper1 = np.array([h1_high, s_high, v_high], dtype=np.uint8)
        lower2 = np.array([h2_low, s_low, v_low], dtype=np.uint8)
        upper2 = np.array([h2_high, s_high, v_high], dtype=np.uint8)

        mask1 = cv2.inRange(hsv, lower1, upper1)
        mask2 = cv2.inRange(hsv, lower2, upper2)
        mask = cv2.bitwise_or(mask1, mask2)

        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel_open, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, self.kernel_dil, iterations=1)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        best_rect = None
        best_area = 0

        for c in contours:
            area = cv2.contourArea(c)
            if area < min_area:
                continue
            peri = cv2.arcLength(c, True)
            eps = approx_eps_ratio * peri
            approx = cv2.approxPolyDP(c, eps, True)
            if len(approx) != 3:
                continue
            if require_convex and not cv2.isContourConvex(approx):
                continue
            hull = cv2.convexHull(c)
            hull_area = cv2.contourArea(hull)
            if hull_area <= 0:
                continue
            solidity = float(area) / float(hull_area)
            if solidity < min_solidity:
                continue
            x, y, w, h = cv2.boundingRect(approx)
            if area > best_area:
                best_area = area
                best_rect = (x, y, w, h)

        if best_rect is not None:
            x, y, w, h = best_rect
            cx = x + w / 2.0
            cy = y + h / 2.0
            bbox = BoundingBox2D()
            center = Pose2D()
            if not self._set_pose2d(center, cx, cy):
                self.get_logger().error('Unknown Pose2D schema; cannot set center')
                return
            bbox.center = center
            bbox.size_x = float(w)
            bbox.size_y = float(h)
            self.pub_bbox.publish(bbox)
            self.get_logger().info(f'centroid_px=({int(cx)},{int(cy)}), size_px=({w}x{h})')
            if self.show_video:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(frame, f'({int(cx)},{int(cy)}) {w}x{h}',
                            (x, max(0, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            (0, 255, 0), 1, cv2.LINE_AA)

        if self.show_video:
            cv2.imshow('Red Triangle - mask', mask)
            cv2.imshow('Red Triangle - frame', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.show_video = False
                cv2.destroyAllWindows()

    def destroy_node(self):
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        super().destroy_node()


def main():
    rclpy.init()
    node = ObjectDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

