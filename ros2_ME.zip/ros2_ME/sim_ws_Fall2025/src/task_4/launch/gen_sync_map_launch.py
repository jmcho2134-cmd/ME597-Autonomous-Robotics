from launch import LaunchDescription 
from launch_ros.actions import Node

def generate_launch_description():
	return LaunchDescription([
	#    Node(
	#       package = 'turtlebot4_navigation' ,
	#       executable = 'slam.launch.py',
	#       namespace = 'robot'
	#       ),
	   Node(
	   	package ='turtlebot4_viz',
	   	executable = 'view_robot.launch.py',
	   	namespace = 'robot'
	       )
	   ])
	
	
