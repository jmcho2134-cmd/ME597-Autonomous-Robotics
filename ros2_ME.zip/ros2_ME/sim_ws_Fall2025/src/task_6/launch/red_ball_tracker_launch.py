from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='task_6',
            executable='red_ball_tracker',
            name='red_ball_tracker',
            parameters=[
                {'image_topic': '/camera/image_raw'},
                {'cmd_vel_topic': '/cmd_vel'},

                # HSV 빨강 범위
                {'h1_low': 0}, {'h1_high': 10},
                {'h2_low': 160}, {'h2_high': 179},
                {'s_low': 100}, {'s_high': 255},
                {'v_low': 80},  {'v_high': 255},

                {'min_area': 300},
                {'morph_open': 1},
                {'morph_dilate': 1},
                {'min_circularity': 0.6},

                {'target_radius_px': 60.0},
                {'near_radius_px': 90.0},
                {'far_radius_px': 40.0},

                {'ang_kp': 1.2}, {'ang_ki': 0.0}, {'ang_kd': 0.15},
                {'lin_kp': 0.015}, {'lin_ki': 0.0}, {'lin_kd': 0.002},

                {'max_lin_vel': 0.35},
                {'max_ang_vel': 1.2},
                {'search_mode': False},
                {'search_ang_vel': 0.4},
                {'lost_timeout': 0.6},

                {'show_debug': True},
            ],
            output='screen'
        ),
    ])

