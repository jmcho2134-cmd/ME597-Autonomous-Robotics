import cv2  
import numpy as np  
import rclpy  
from rclpy.node import Node 
from sensor_msgs.msg import Image, CameraInfo  
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge

class RedBallFollower(Node): 
    def __init__(self):
        super().__init__('red_ball_follower')  
	
	#Topic 
        self.declare_parameter('image_topic', '/camera/image_raw')  
        self.declare_parameter('camera_info_topic', '/camera/camera_info')  
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')  
	
	#HSV
        self.declare_parameter('hsv_H_low1', 0)   
        self.declare_parameter('hsv_H_high1', 10)  
        self.declare_parameter('hsv_H_low2', 160)  
        self.declare_parameter('hsv_H_high2', 179) 
        self.declare_parameter('hsv_S_low', 110)  
        self.declare_parameter('hsv_V_low', 80)    
	
	#Ball parameter
        self.declare_parameter('ball_size', 0.12)    
        self.declare_parameter('target_dist', 0.30)   
        self.declare_parameter('distant_band', 0.03)  
        self.declare_parameter('allign_band', 0.08)   
	
	#PID parameter
        self.declare_parameter('angular_kp', 1.2)   
        self.declare_parameter('angular_ki', 0.0)   
        self.declare_parameter('angular_kd', 0.20)  
        self.declare_parameter('angular_vmax', 2.2) 

        self.declare_parameter('linear_kp', 1.4)    
        self.declare_parameter('linear_ki', 0.0)    
        self.declare_parameter('linear_kd', 0.10)  
        self.declare_parameter('linear_vmax', 1.5)  
        self.declare_parameter('back_vmax', 1.5)    

        self.declare_parameter('min_abs_lin', 0.05)  # Minimun linear speed to overcome static friction
        self.declare_parameter('min_abs_ang', 0.01)  # Minimum angular speed to overcome static friction

        self.declare_parameter('searching_ang', 1.0)  
        self.declare_parameter('show_window', True)   
        self.declare_parameter('visualize', 0.5)      

        self.bridge = CvBridge()  
        self.fx = None            # Focal length fx from CameraInfo (pixels)

        self.last_t = self.get_clock().now()  # Time of previous callback
	
	#subscriber (image ,camera)
        self.sub_img = self.create_subscription(Image, self.p('image_topic'), self.on_image, 10)       
        self.sub_cinfo = self.create_subscription(CameraInfo, self.p('camera_info_topic'), self.on_cinfo, 10)  
        
        #publisher (velocity cmd) 
        self.pub_cmd = self.create_publisher(Twist, self.p('cmd_vel_topic'), 10) 

        # PID controllers
        self.ang_pid = PID(self.p('angular_kp'), self.p('angular_ki'), self.p('angular_kd'),
                           -self.p('angular_vmax'), self.p('angular_vmax'))
        self.lin_pid = PID(self.p('linear_kp'), self.p('linear_ki'), self.p('linear_kd'),
                           -self.p('back_vmax'), self.p('linear_vmax'))


        if bool(self.p('show_window')):
            cv2.namedWindow('RB-frame', cv2.WINDOW_NORMAL)
            cv2.namedWindow('RB-mask', cv2.WINDOW_NORMAL)

    # reading parameter 
    def p(self, name):
        return self.get_parameter(name).value  

    def on_cinfo(self, m: CameraInfo):
       
        if len(m.k) == 9 and m.k[0] > 0:
            self.fx = float(m.k[0])

    def on_image(self, msg: Image):
        now = self.get_clock().now()                  
        dt = (now - self.last_t).nanoseconds / 1e9    # Callback interval [s]
        self.last_t = now                              

        frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')  # ros image -> opencv rgb
        H, W = frame.shape[:2]                          
        cx_img = W / 2.0                               
        blur = cv2.medianBlur(frame, 5)                 # eeduce noise
        hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)    

        # read HSV
        h1_low, h1_high = int(self.p('hsv_H_low1')), int(self.p('hsv_H_high1'))
        h2_low, h2_high = int(self.p('hsv_H_low2')), int(self.p('hsv_H_high2'))
        s_low, v_low = int(self.p('hsv_S_low')), int(self.p('hsv_V_low'))

        # build red mask 
        m1 = cv2.inRange(hsv, (h1_low, s_low, v_low), (h1_high, 255, 255))
        m2 = cv2.inRange(hsv, (h2_low, s_low, v_low), (h2_high, 255, 255))
        mask = cv2.bitwise_or(m1, m2)

        # clean noise / fill small holes
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)

        # contours
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = cnts[0] if len(cnts) == 2 else cnts[1]

        
        found = False
        x = y = w = h = 0

       
        if contours:
            c = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(c)
            if w >= 6 and h >= 6:
                found = True

        cmd = Twist()  

        if found: # (search and found ) 
            cx_obj = x + w / 2.0
            x_err = (cx_obj - cx_img) / (W * 0.5)

            # allign camera to center
            ang = self.ang_pid.step(-x_err, max(dt, 1/60.0))

            if abs(x_err) > float(self.p('allign_band')) * 1.5:
                min_ang = float(self.p('min_abs_ang'))
                if 0.0 < abs(ang) < min_ang:
                    ang = min_ang if ang >= 0 else -min_ang

            # linear control using pinhole depth estimate
            if self.fx is not None:
                D = float(self.p('ball_size'))            
                s_px = max(1.0, float(max(w, h)))         # pixel distance approx
                Z = (self.fx * D) / s_px                   # distance estimated 
                target = float(self.p('target_dist'))      # desired distance
                band = float(self.p('distant_band'))       # deadband
                z_err = Z - target                         # positive = too far

                if abs(z_err) <= band:
                    lin = 0.0
                    self.lin_pid.reset()                   # Reset integrator near target
                else:
                    lin = self.lin_pid.step(z_err / max(1e-6, target), max(dt, 1/60.0))
                    if 0.0 < abs(lin) < float(self.p('min_abs_lin')):
                        lin = float(self.p('min_abs_lin')) if lin >= 0 else -float(self.p('min_abs_lin'))
            else:
                lin, ang = 0.0, 0.0  # Safe stop 

            # gate linear motion until roughly centered
            if abs(x_err) > float(self.p('allign_band')):
                lin = 0.0

            # applying saturation limits
            cmd.angular.z = float(np.clip(ang, -self.p('angular_vmax'), self.p('angular_vmax')))
            cmd.linear.x  = float(np.clip(lin, -self.p('back_vmax'), self.p('linear_vmax')))
        else:
            # searching if no ball
            cmd.angular.z = float(np.clip(self.p('searching_ang'), -self.p('angular_vmax'), self.p('angular_vmax')))
            cmd.linear.x = 0.0

        # publish velocity cmd
        self.pub_cmd.publish(cmd)

        # visualization
        if bool(self.p('show_window')):
            disp = frame.copy()
            if found:
                cv2.rectangle(disp, (int(x), int(y)), (int(x + w), int(y + h)), (0, 255, 0), 2)
                cv2.putText(disp, f'({int(x + w/2)},{int(y + h/2)}) {w}x{h}', (x, max(0, y - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
            scale = float(self.p('visualize'))
            if 0.05 <= scale < 2.0 and abs(scale - 1.0) > 1e-3:
                h_img, w_img = disp.shape[:2]
                disp = cv2.resize(disp, (int(w_img * scale), int(h_img * scale)))
                msk = cv2.resize(mask, (int(w_img * scale), int(h_img * scale)))
            else:
                msk = mask
            cv2.imshow('RB-frame', disp)
            cv2.imshow('RB-mask', msk)
            cv2.waitKey(1)

class PID:  #  PID controller
    def __init__(self, kp=0.0, ki=0.0, kd=0.0, umin=-1e9, umax=1e9):
        self.kp, self.ki, self.kd = float(kp), float(ki), float(kd)  # gains
        self.umin, self.umax = float(umin), float(umax)              # limits
        self.i = 0.0        # integral term
        self.e_prev = None  # prev error

    def reset(self):
        self.i = 0.0        # reset integral
        self.e_prev = None  # reset prev error

    def step(self, e, dt):
        dt = max(float(dt), 1e-6) 
        de = 0.0 if self.e_prev is None else (e - self.e_prev) / dt  # rror derivative
        u_try = self.kp * e + self.ki * (self.i + e * dt) + self.kd * de  # try output for saturation
        if self.umin < u_try < self.umax:
            self.i += e * dt  # integrate only if not saturated
        self.e_prev = e
        u = self.kp * e + self.ki * self.i + self.kd * de  #  output
        return max(self.umin, min(self.umax, u))  

def main():
    rclpy.init()              
    node = RedBallFollower()  
    try:
        rclpy.spin(node)      
    except KeyboardInterrupt:
        pass                 
    node.destroy_node()     
    rclpy.shutdown()         
    try:
        cv2.destroyAllWindows()  
    except Exception:
        pass                  

if __name__ == '__main__':
    main()  # Entry point
