import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import numpy as np

class PIDControllerNode(Node):
    def __init__(self):
        super().__init__('pid_speed_controller') # node name 

        # Initial setting 

        # PID Gains 
        self.kp = 0.1 # P gain
        self.ki = 0.036 # I gain 
        self.kd = 0.10# D gain 

        self.target_distance = 0.35  # target distance 
        self.prev_error = 0.0 #  previous error (Derivative)
        self.integral = 0.0 # error summation (Integral)

        # Publisher and Subscriber
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)  # (Publishing Velocity to robot topic name : cmd_vel , message type : Twist)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)  #(Subscribing Lidar data from senosr : topic name scan , message type : LaserScan)

        # Timer for control loop
        self.timer = self.create_timer(0.1, self.control_loop)  # 10 Hz

        self.forward_distance = None  # save new distance value __init__('pid_speed_controller')

    def scan_callback(self, msg: LaserScan):
        # forward range data 
        forward_range = msg.ranges[0]
        
        self.get_logger().info(f"LiDAR forward range: {forward_range}")
        
        if np.isfinite(forward_range):
        	self.forward_distance = forward_range
        	self.get_logger().info(f"forward_distance set to: {self.forward_distance}")
        else:
        	self.get_logger().warn("Invalid LIDAR Data.")
        


    def control_loop(self):
    
        if self.forward_distance is not None:         
            error = self.forward_distance - self.target_distance
            self.integral += error * 0.1  # dt = 0.1s
            derivative = (error - self.prev_error) / 0.1
            self.prev_error = error

        if self.forward_distance is None:
           output = 1.0
           self.get_logger().info("forward_distance is None.")    
        elif self.forward_distance <= self.target_distance:
           output = 0.0 
        else: 
           output = self.kp * error + self.ki * self.integral + self.kd * derivative
           # speed limit
           output = max(min(output, 0.15), -0.15)

        # speed publish 
        twist = Twist()
        twist.linear.x = output
        twist.angular.z = 0.0
        self.cmd_vel_pub.publish(twist)

       
def main(args=None):
    rclpy.init(args=args)
    node = PIDControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
